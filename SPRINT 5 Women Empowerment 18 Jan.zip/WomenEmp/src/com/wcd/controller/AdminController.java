package com.wcd.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.wcd.service.INgoDetailService;
import com.wcd.service.IUserReg;

import model.Ngo;
import model.NgoDetails;

import model.UserRegistration;

@Controller
public class AdminController {
	@Autowired
	private IUserReg userRegService;
	
	 public void setUserRegService(IUserReg userRegService) {
		this.userRegService = userRegService;
	}

	@Autowired
	  INgoDetailService ngodetService;

	public void setNgodetService(INgoDetailService ngodetService) {
		this.ngodetService = ngodetService;
	}
	@RequestMapping(value = "/AdminLogin", method = RequestMethod.GET)
	public String indexes(Model model) {
		model.addAttribute("adminLogin",new Ngo());
		return "adminLogin";
	}
	
	
	/*added by pooja and allwyn*/
	@RequestMapping(value = "/faq", method = RequestMethod.GET)
	public String faq(Model model) {
		model.addAttribute("adminLogin",new Ngo());
		return "faq";
	}
	
	
	
	
	 @RequestMapping(value = "/AdminLoginForms", method = RequestMethod.POST)
	  public ModelAndView LoginValidation(@ModelAttribute("adminLogin") @Valid Ngo
	  n,BindingResult result,Model model,HttpServletRequest req,HttpSession
	  session) {
		 ModelAndView mav=new ModelAndView();
	  String username=req.getParameter("name"); 
	  String password=req.getParameter("password");
	  if(username.equalsIgnoreCase("admin")&&password.equalsIgnoreCase("1234"))
	  {mav.setViewName("adminDashboard");
	  session.setAttribute("adminName", username);
	  List<NgoDetails> ngoDetList =this.ngodetService.listNgoDetail();
		model.addAttribute("ngoDetList", ngoDetList);
		List<UserRegistration> userList =this.userRegService.listUserRegDetail();
		model.addAttribute("userList", userList);
		  }else mav.setViewName("index");
	  return mav;
	  }
	
	
}
